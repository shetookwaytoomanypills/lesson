//let dict = ["машина" : "car", "мужик" : "man"]

//dict["мужик"]

/*
var dict = ["машина" : "car", "мужик" : "man"]

dict.count
dict.isEmpty

var dict3 = [String:String]()
dict3.count
dict3.isEmpty

dict["комп"] = "computer"
dict

Array(dict.keys)
Array(dict.values)

dict.updateValue("mac", forKey: "комп")
dict

//let comp = dict["комп"]

if let comp = dict["комп"] {
    print("\(comp)")
} else {
    print("no value for key \("комп")")
}

//dict["мужик"] = nil
//dict

//dict.removeValue(forKey: "комп")
dict

//dict = [:]
dict.isEmpty
dict["hello"] = "world"
dict


for key in dict.keys {
    print("key = \(key), value is \(dict[key]!)")
}


for (key, value) in dict {
    print("key is \(key), value is \(value)")
}
*/


/*
 дз 08 - дикшинари 31:00
 1: создать дикшинари как журнал студентов где ключ имя и фамилия а значение оценка. повысить двум студентам оценку, потом добавить новых студентов с их оценками, затем убрать старых студентов, после этого посчитать общий балл этой группы, средний балл этой  группы
 
 2: создать дикшинари с ключами - названями месяцев а количество дней - значение, вывести на экран через тюплы, и через цикл
 
 3: создать дикшинари в котором ключ это адрес клетки на шахманой доске, а значение - true если клетка белая, и false если клетка черная. создавать дикшинари нужно циклом.
 */


var studentDict = ["Alex Skutarenko" : 5, "Nikita Barabanov" : 2, "Sergey Uvarov" : 5, "Konstantin Hamicevich" : 5 ]

studentDict["Nikita Chepak"] = 4
studentDict["Ivan Panasuk"] = 5
studentDict.updateValue(3, forKey: "Nikita Barabanov")
studentDict.updateValue(5, forKey: "Nikita Chepak")
studentDict.removeValue(forKey: "Nikita Barabanov")
studentDict.removeValue(forKey: "Sergey Uvarov")


var avg = 0
var sumOfValues = 0
for i in studentDict.keys {
    sumOfValues += studentDict[i]!
}
sumOfValues

for g in studentDict.keys {
    avg += studentDict[g]!
}
avg = avg / studentDict.count
avg



var yearDict = ["jan" : 31, "feb" : 28, "mar" : 31, "apr" : 30, "may" : 31, "jun" : 30, "jul" : 31, "aug" : 31, "sep" : 30, "oct" : 31, "nov" : 30, "dec" : 31]

for (key, value) in yearDict {
    print("key is \(key), value is \(value)")
}

for key in yearDict.keys {
    print("key is \(key), value is \(yearDict[key]!)")
}




/*
 с третьим заданием возникили сложности. я не смог додуматься как создать дикшинари с помощью цикла и пошел гуглить, но не нашел там ничего, открыл свифтбук, прочитал тему типы коолекций, но там тоже ничего, тогда зашел на ролик разбора домашки по этой теме, там в этом задании использовался конструктор, который у меня не работает, возможно он был удален...
 */
