/*
var age = 21

if age == 21 {
    
} else if age == 22 {
    
} else {
    
}

switch age {
    case 0...16: print("школота")
    case 17...21: print("студент")
    case 22...50: print("рабочий")
    default: break
}
mainLoop: for _ in 0...1000 {
    for var i in 0..<20 {
        if i == 10 {
            break mainLoop
        }
        print(i)
    }
}


var name = "alex"
age = 66

switch name {
case "alex" where age < 50:
    print("hi buddy!")
case "alex" where age >= 50:
    print("I don't know you")
default:
    break
}


switch (name, age) {
case ("alex", 60):
    print("hi alex 60")
case ("alex", 59):
    print("hi alex 59")
case (let localName, let number) where number >= 65 && number <= 70:
    print("hi stranger")
case ("alex", _):
    print("hi alex")
default:
    break
}


let point = (5,-5)

switch point {
case let (x,y) where x == y:
    print("x = y")
case let (x,y) where x == -y:
    print("x = -y")
case let (_,y) where y < 0:
    print("y < 0")
default:
    break
}


let tuple = (5, 5.4, Float(5.4))
switch tuple.2 {
case let a as Int:
    print("Int")
case let a as Double:
    print("Double")
case let a as Float:
    print("Float")
    
    
default:
    break
}
*/
/*
 ДЗ
 1 задание.
 создать произвольный текст длиной в 200 символов, с помощью  оператора switch, вложенного в цикл посчитать: количество гласных, количество знаков препинания, количество цифр.
 
 2 задание.
 создать свитч, который принимает возраст человека, а выводит название периода жизни, соотвествующее этому возрасту.
 
 3 задание.
 есть студент с фамилией, именем и отчеством (три строки)  если его имя начинается с а или о то вывести на экран имя студента  если его отчество начинается с буквы  в или буквы д то вывести на экран имя и отчество студента, если же его фамилия начинается с букв е или з то вывести на экран только фамилию, если ничего из этого не выполняется то вывести на экран фамилию имя и отчество этого студента
 */

//2

let hwAge = 17

switch hwAge {
case 0...18:
    print("school")
case 19...24:
    print("university")
case 24...70:
    print("job")
case 70...99:
    print("drink beer and quarrel with neighbours")
default:
    print("heaven")
}


//1

let text = "i went to my garden and saw peaceful view: butterflies were flying and some other insects were on the floor. then i felt spring atmosphere"
var arrayOfText = Array(text)

var vowelCounter = 0
var Counter = 0
var pMarkCounter = 0

for var i in arrayOfText {
    switch arrayOfText[0] {
    case "a", "e", "i", "o", "u", "y", "A", "E", "I", "O", "U", "Y":
        vowelCounter += 1
    case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
        Counter += 1
    case ",", ".", "!", "?", ";", ":", "-":
        pMarkCounter += 1
    default:
        break
    }
    arrayOfText.remove(at: 0)
}
print("количество гласных = \(vowelCounter)")
print("количество цифр = \(Counter)")
print("количество знаков препинания = \(pMarkCounter)")


//3

let student = ("Чепак", "Никита", "Николаевич")
switch student {
case _ where student.1.hasPrefix("А") || student.1.hasPrefix("О"):
    print(student.1)
case _ where student.2.hasPrefix("В") || student.2.hasPrefix("Д"):
    print(student.1, student.2)
case _ where student.0.hasPrefix("Е") || student.0.hasPrefix("З"):
    print(student.0)
default:
    print("\(student.0) \(student.1) \(student.2)")
}


//4

let array = [(5, 6), (6, 6), (7, 6)]
let point0 = (x:5, y:6)
let point1 = (x:6, y:6)
let point2 = (x:7, y:6)

switch array {
case _ where point0 == array[0]:
    print("попал")
case _ where point1 == array[1]:
    print("попал")
case _ where point2 == array[2]:
    print("попал")
case _ where (point0 == array[0]) && (point1 == array[1]) && (point2 == array[2]):
    print("убил")
default:
    print("мимо")
}
